package org.example.model;

public interface Stack {
    int getTop();
    boolean isEmpty();
    void add(int a);
    void remove();
}